# ADR 0009: One admin login, password in Secrets Manager

**Status:** Accepted on 8 Oct (ALPHA-81).
**Decision in one line:** login accepts only the admin account, whose password lives in Secrets Manager, and sign-up is closed.

## Context

`/auth/login` returned a valid token for any email and password, and `/auth/register` handed a token to anyone. The only screen is the admin dashboard, and the dashboard page had the admin password written in its code.

## Options

| Option | What it is | Result |
|---|---|---|
| **A. One admin account from a secret (chosen)** | `ADMIN_EMAIL` plus `ADMIN_PASSWORD` from Secrets Manager; the page asks for them | Closes "anyone can log in" today. No user data to manage. |
| B. A user table with hashed passwords | Sign-up, login against stored Argon2id hashes, roles | The right end state for customers. Needs a hashing library, account management and ownership checks across services; too much to do safely before the deadline. |
| C. An identity provider (Cognito or similar) | Login handled outside the app | More AWS cost and setup than one admin screen needs. |

## Decision

- The gateway compares the login with the admin account. It keeps only a SHA-256 of the password and compares in constant time.
- A wrong email and a wrong password both get 401 with the same message, as OWASP recommends.
- If `ADMIN_PASSWORD` is missing, the gateway still starts and refuses every login, so a late secret doesn't take the API down.
- Sign-up returns 403.
- The token carries `role: admin`. The gateway deletes any `X-User-Email` or `X-User-Role` a client sends, and sets them only from a checked token.
- The page shows a login box and keeps the token in memory only.
- Terraform makes the password: 32 random letters and digits, written only to Secrets Manager.

## Consequences

- Everyone who uses the dashboard shares one account and one rate limit, and the audit trail shows the admin, not a person.
- Login is limited to 20 tries a minute per IP. There is no per-account lockout; with a 32-character random password, guessing is not a practical attack.
- Orders are recorded against the admin's email, so emails go to the admin.
- Rotating the password: change the secret in Secrets Manager. External Secrets picks it up within 15 minutes and Reloader restarts the gateway.

## How we know it works

Gateway tests: right password, email in another case, wrong password, other email, empty password, no password configured, sign-up closed, token claims, identity headers from a client. Breaking the password check makes the test fail. A browser test of the page: login box first, wrong password stays locked, right password loads the data, nothing in browser storage.

## Revisit when

Customers or more than one staff member need to log in. Then option B, with Argon2id hashes and ownership checks on orders and payments.

## References

[OWASP Authentication Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Authentication_Cheat_Sheet.html), [OWASP Password Storage Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html), [Go `crypto/subtle`](https://pkg.go.dev/crypto/subtle#ConstantTimeCompare)
