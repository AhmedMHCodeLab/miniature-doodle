# ADR 0008: Every new order carries an Idempotency-Key

**Status:** Accepted on 7 Oct (ALPHA-81).
**Decision in one line:** `POST /orders` requires an `Idempotency-Key` header; the same key with the same request returns the first order, so a retried request never makes a second one.

## Context

A stakeholder asked how a double submit is prevented, including someone calling the API directly. Payments were already safe (one completed charge per order, ADR 0002), but placing an order was not: if the reply to `POST /orders` was lost, the client could only send it again, and that made a second order.

## Options

| Option | What it is | Result |
|---|---|---|
| **A. Client sends an `Idempotency-Key` (chosen)** | The Stripe pattern, also an IETF draft. The client makes a random key per order and reuses it on a retry. | Exact: a retry is recognised even if the basket is the same as a real second order. |
| B. Treat "same customer, same basket, within N seconds" as a duplicate | No client change | Blocks a customer who really wants two of the same order, and still misses a retry after N seconds. |
| C. Disable the button in the page only | Front-end only | Does nothing for direct API calls or a lost reply. |

## Decision

- The header is required. Missing: 400. Over 255 characters: 400.
- The key is scoped to the customer and stored in `idempotency_keys` with a SHA-256 of the request (items, currency, notes, shipping address).
- The key is claimed inside the same transaction as the order. Two identical requests at the same moment make one order; the second waits and then gets the first one's answer.
- Same key, same request: 200 with the first order and `Idempotent-Replayed: true`. Same key, different request: 422.
- A failed attempt (bad product, inventory down) saves nothing, so the same key can be used again.
- Keys are deleted after 24 hours by the scheduler, as Stripe does. A retry after that is a new order.
- The dashboard makes one key per order and reuses it only when the first try got no clear answer.

## Consequences

- Breaking change for clients: any caller of `POST /orders` must send the header. The dashboard does.
- Replays are answered before pricing, so they work while inventory is down.
- The request hash leaves out the address when there is none, so keys stored before addresses existed still match.

## How we know it works

order-service: 8 tests (same key twice, 10 at once repeated 20 times, different request, missing and long key, inventory down, failed attempt, keys per customer) plus 1 for addresses. The smoke test sends the same key twice through the public URL and checks it gets the same order.

## Revisit when

A second client (a shop front, a mobile app) starts placing orders: it must generate keys the same way.

## References

[Stripe: idempotent requests](https://docs.stripe.com/api/idempotent_requests), [IETF draft: The Idempotency-Key HTTP Header Field](https://datatracker.ietf.org/doc/draft-ietf-httpapi-idempotency-key-header/)
