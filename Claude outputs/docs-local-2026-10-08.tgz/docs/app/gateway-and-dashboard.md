# Gateway and dashboard

Describes: `main` as of 3 Oct (`e300366`). PRs #25 and #29 are merged.

This page covers how requests get into the app and how they are limited.

- Everything goes through api-gateway on port 8080. That includes the dashboard page, because the page calls `/api` and `/auth` on whatever address served it. Opened on 8086, those calls get a 404.
- Limits per 60 seconds: 120 per logged-in user, 60 per IP when not logged in, and 20 per IP on login, register and the shipping webhook. Over the limit you get a 429 and a `Retry-After` header.
- If Redis is down, requests are let through, and the gateway logs it and counts it.
- This is a stopgap. Per-IP limits move to Traefik once it runs on EKS (ADR 0003).
- Every dashboard tab logs in as the same admin user and so shares one limit. That's why the dashboard refreshes every 30 seconds.

---

## 1. Where requests go

| Request path | Goes to | Notes |
|---|---|---|
| `/` | dashboard-api | The dashboard page. No token needed for the page itself. |
| `/dashboard/...` | dashboard-api | Path kept as is, because dashboard-api serves it under `/dashboard/`. |
| `/api/orders/...` | order-service | The `/api/orders` part is removed before forwarding. The same happens for every `/api/...` route. |
| `/api/inventory/...` | inventory-service | |
| `/api/payments/...` | payment-service | |
| `/api/shipping/...` | shipping-service | `/api/shipping/webhook` needs no token. |
| `/api/notifications/...` | notification-service | |
| `/api/dashboard/...` | dashboard-api | |
| `/auth/login`, `/auth/register` | the gateway itself | Returns a token valid for 24 hours. Login accepts any email and password for now. |
| `/healthz`, `/api/<service>/healthz` | gateway / each service | No token needed. |

Every other request needs `Authorization: Bearer <token>`.

---

## 2. How the limiter decides who you are

| Who | Counted by | Limit per 60 s | Applies to |
|---|---|---|---|
| Logged-in user | User ID inside the token (`sub`) | 120 | All normal API calls |
| Not logged in | Client IP | 60 | Public paths such as health checks |
| Sensitive paths | Client IP | 20 | `/auth/login`, `/auth/register`, `/api/shipping/webhook` |

Details that matter:

- The client IP is the address that connected, without the port. `X-Forwarded-For` and `X-Real-IP` are believed only when the request comes from a proxy listed in `TRUSTED_PROXY_CIDRS`. Locally that list is empty, so nobody can fake their IP.
- Counters live in Redis under keys like `rl:user:<hash>`. The ID is hashed, so no emails or IPs are stored in Redis.
- Counting and setting the expiry happen in one Redis step, so a crash can't leave a counter that never resets.
- If Redis doesn't answer within 100 ms, the request is allowed (fail open). The gateway logs this at most once every 10 seconds.

Watch it with the metric `gateway_rate_limit_decisions_total{scope, result}` on port 9090 inside the container (9091 on your laptop). That port is never routed through the gateway.

---

## 3. How the dashboard behaves

1. The page loads from `/` on 8080.
2. It logs in as `admin@platform.local` and waits for the token before loading any data.
3. It loads its tables, then refreshes every 30 seconds.
4. It logs in again every hour, so an open tab never hits the 24-hour token expiry.

Why 30 seconds: one refresh makes 8 data calls. At the old 10 seconds that's 48 calls a minute per tab. Three open tabs make 144, over the 120 limit they share. At 30 seconds one tab makes 16 a minute, so 7 tabs fit.

---

## 4. Rules that must stay true

1. The gateway is the only way in. On EKS, nothing else is exposed.
2. Forwarding headers are trusted only from known proxies. Otherwise anyone can pick their own IP and dodge the limit.
3. Login, register and the webhook keep the stricter per-IP limit.
4. The metrics port is never routed through the gateway.
5. The dashboard loads data only after it has a token.

---

## 5. Why it is built this way

**What was wrong before.** The old limiter counted by IP and port. Every new connection has a new port, so every connection got a fresh allowance and nothing was ever limited: 150 separate requests all returned 200. Login and register had no limit at all.

**The choices we made for now** (full reasoning in ADR 0003):

| Question | Options | What we picked | Why |
|---|---|---|---|
| Where do limits live? | Gateway only, or Traefik at the edge | Gateway only, for now | Traefik isn't running yet. Per-user limits need the token, which only the gateway reads. |
| How are requests counted? | Fixed 60 s window, or a token bucket | Fixed window | Simple, and fine for the first version |
| What if Redis is down? | Let requests through, or block them | Let them through | A Redis blip shouldn't take the whole shop down. It's logged and counted. |

**Dashboard:** it needs the same address as the API because the page uses paths like `/api/orders` without a host. Serving it from the gateway fixes that with one route and no changes to the page's paths. Slowing the refresh was the quick fix for the shared limit. The proper fix, giving the dashboard its own identity and limit, needs real staff logins, so it waits for hardening.

---

## 6. What changes when Traefik arrives

- Per-IP limiting can move to Traefik's RateLimit middleware, with its counters shared in Redis across replicas.
- `TRUSTED_PROXY_CIDRS` must then list Traefik's addresses, or every request will look like it comes from Traefik's IP.
- Per-user limits stay in the gateway.

---

## 7. How we know it works

- 10 gateway limiter tests, run against real Redis with the race detector.
- 22 logins in a row from one client gave 20 successes and 2 blocks (429). Before the fix, all 22 succeeded.
- 5 routing tests: the page is served without a token, `/dashboard/` keeps its path, data still needs a token, the other routes still strip their prefix, unknown paths give a 404.
- First load before the fix: 6 data calls went out before login finished and all got 401. After: 0 of 7 rejected in a browser test.
- Live on 8080: an order was placed from the page and confirmed, a product was added, and all 7 service dots were green.

---

## 8. Settings

| Variable | Default | What it does |
|---|---|---|
| `RATE_LIMIT_WINDOW_SECONDS` | 60 | Window length |
| `RATE_LIMIT_USER_PER_WINDOW` | 120 | Per logged-in user |
| `RATE_LIMIT_IP_PER_WINDOW` | 60 | Per IP, not logged in |
| `RATE_LIMIT_SENSITIVE_PER_WINDOW` | 20 | Per IP on login, register, webhook |
| `TRUSTED_PROXY_CIDRS` | empty | Proxies whose forwarding headers are believed |
| `METRICS_PORT` | 9090 | Prometheus metrics |
| `REDIS_URL` | none | Redis for the counters |
| `DASHBOARD_SERVICE_URL` | `http://dashboard-api:8086` | Where the page and `/dashboard/` go |

Known small gaps, all in the hardening backlog:

- When forwarding, the gateway sets `X-Forwarded-For` to `ip:port`.
- A request with an invalid token isn't counted.
- The "limited" log line isn't throttled.

Next: Run, build, test.
