# Application: start here

Describes: `main` as of 3 Oct (`e300366`), including the Sprint 2 fixes (PRs #23, #24, #25, #29, #31, #32, #33).

**What this is.** The application side of the EKS v2 order platform. 9 Go services sit behind one gateway, share one Postgres database, and pass order events through one SQS queue.

**What changed in Sprint 2.** Before, every order stayed `pending` forever. order-service only logged its events and the worker never read the queue. Now an order placed through the gateway gets its stock held, gets charged, gets confirmed, and its stock is taken off the shelf. You can watch it happen on the dashboard.

**How we worked.** Fix first, harden later. What is not safe yet is listed near the bottom of this page.

**Read next.** How an order flows (15 minutes). If you want to see it working first, go to Run, build, test and follow "Place an order" (5 minutes).

---

## The services

| Service | Local port | What it does |
|---|---|---|
| api-gateway | 8080 | The front door. Login, rate limits, routes `/api/...` to the services, serves the dashboard page. |
| order-service | 8081 | Orders and their status. Sends order events to SQS. |
| inventory-service | 8082 | Products and stock holds (reserve, release, commit). |
| payment-service | 8083 | Charges, refunds, ledger. The card provider is simulated and declines about 1 in 10 charges. |
| notification-service | 8084 | Records notifications. Nothing is actually sent yet. |
| shipping-service | 8085 | Shipments. Not reached in the order flow yet, because orders have no address. |
| worker | none (health on 8090) | Reads the queue and drives each order through its steps. |
| scheduler | none | Timed jobs: expire stock holds (every minute), abandoned orders (5 min), payment retries (15 min), event cleanup (30 min), digest (hourly). |
| dashboard-api | 8086 | The admin page and its reports. |

Also running: Postgres (5432), Redis (6379, used by the rate limiter) and Floci (4566, a local stand-in for AWS).

Only 8080 is the real way in. The other ports are open on your machine so you can call one service directly while debugging. On EKS only the gateway will be reachable from outside.

```
 browser or curl
       |
       v
 api-gateway :8080 ------ redis (rate limits)
       |
       +--> order-service ---- saves order + event together ----> postgres
       |          |
       |          | relay sends the event (about 1 second)
       |          v
       |    SQS queue "order-events" ----> worker ----> inventory, payment, order-service
       |          |
       |          | after 3 failed tries
       |          v
       |    "order-events-dlq"
       |
       +--> inventory, payment, shipping, notification, dashboard-api
```

All services use the same Postgres instance.

---

## The order journey in 6 steps

1. The customer places an order through the gateway. order-service saves it as `pending`, together with its event, in one database transaction.
2. order-service sends the event to SQS, usually within a second.
3. The worker picks it up and asks inventory to hold the stock.
4. The worker asks payment to charge.
5. The worker marks the order `confirmed`.
6. The worker tells inventory to commit the held stock. The items are now sold.

If the stock is short or the card is declined, the worker undoes what it did and cancels the order. The details are in How an order flows.

---

## What changed in Sprint 2

| Problem | Fix | Ticket and PR | Read more |
|---|---|---|---|
| Events were only logged, so orders stayed pending | Outbox and SQS publisher | ALPHA-44, #23 | How an order flows, ADR 0001 |
| The worker never read the queue | Worker consumer, which checks the order's status before each run | ALPHA-45, #33 | How an order flows |
| A retried message could charge twice, hold stock twice, push `reserved` below zero, or let confirm and cancel both win | Database rules make every step safe to repeat | ALPHA-51, #31 | How an order flows, ADR 0002 |
| Sold stock came back on sale after 15 minutes | Stock commit | ALPHA-77, #32 | How an order flows |
| The rate limiter never limited anyone, and login had no limit | Limit by user and by real IP | ALPHA-73, #25 | Gateway and dashboard, ADR 0003 |
| Dashboard broken on 8086 and empty on first load | Serve it through the gateway | ALPHA-48, #29 | Gateway and dashboard |
| No way to see which service holds database connections | Connection names and pool metrics | ALPHA-74, #24 | Run, build, test |

Earlier groundwork: Dockerfiles for all 9 services (ALPHA-56, #15) and Floci for local AWS (ALPHA-61, #3).

---

## Not safe yet

These work for honest users on a normal day, but should not be relied on:

- Login accepts any email and password. There is no user store.
- Any logged-in user can read or change any order, and the order total comes from the request. (ALPHA-46, ALPHA-50)
- Orders stop at `confirmed`. There is no address, so no shipment, and notifications are never sent. (ALPHA-78)
- Refunds are not safe to repeat. (ALPHA-78)
- Run the scheduler as 1 replica only. Every copy runs every job.
- Database pool sizes are not decided yet. (ALPHA-80)

The full list, with what "done" means for each item, is the App hardening plan (ALPHA-81).

---

## Words you'll see

| Word | Meaning here |
|---|---|
| Event | A small JSON message saying something happened, like `order.created`. |
| Outbox | The `order_outbox` table. Events are saved here with the order, then sent. |
| Relay | The loop inside order-service that sends outbox rows to SQS. |
| At least once | SQS always delivers, but sometimes delivers the same message twice. |
| Safe to repeat | Doing the same call twice has the same result as doing it once. Also called idempotent. |
| Hold (reservation) | Stock set aside for an order. It expires after 15 minutes unless committed. |
| Commit | Turning a hold into a sale. Stock goes down for good. |
| DLQ | Dead letter queue. Where a message goes after 3 failed tries. |
| Visibility timeout | How long SQS hides a message from others while one worker handles it. |
| Long polling | Asking SQS to wait up to 20 seconds for a message instead of answering empty straight away. |
| Floci | A local program that pretends to be AWS, so we can run SQS on a laptop for free. |

---

## Reading path

| Time | Read | You should now know |
|---|---|---|
| 5 min | This page | What each service does and what Sprint 2 fixed |
| 15 min | How an order flows, up to "Rules that must stay true" | The full order journey, what happens on failure, what not to break |
| 30 min | Run, build, test: "Place an order". Then Gateway and dashboard, top section | How to run it, watch an order confirm, and why 8080 matters |
| Deeper | Order events queue (SQS) | How the queue is set up in AWS and what the app needs from it |
| Deeper | Redis in the cluster | Where the rate-limit counters live on EKS, and what happens when Redis restarts |
| Deeper | The ADRs | The options we weighed and why we picked what we did |
